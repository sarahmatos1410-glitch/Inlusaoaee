
import { GoogleGenAI } from "@google/genai";
import { DailyLog, Student } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const analyzeStudentProgress = async (logs: DailyLog[], student: Student) => {
  const logSummary = logs.map(l => 
    `Data: ${l.date}, Comportamento: ${l.behavior}, Adaptadas: ${l.realizouAtividadesAdaptadas ? 'Sim' : 'Não'} (${l.componentesCurriculares}), Ajuda: ${l.tipoAjuda || 'N/A'}, Recusa: ${l.houveRecusa ? 'Sim' : 'Não'}, Dif. Auxiliar: ${l.dificuldadeEntendimentoAuxiliar ? 'Sim' : 'Não'}, Áreas Específicas: ${l.participouAreasEspecificas ? 'Sim' : 'Não'} (${l.areasEspecificasDetalhadas || 'N/A'})`
  ).join('\n');

  const prompt = `
    Analise o progresso do aluno ${student.name} (${student.needs}) com base nestes registros diários de AEE:
    
    ${logSummary}
    
    Considere especialmente:
    1. Se as atividades adaptadas estão sendo bem compreendidas pelos auxiliares (indicador: Dif. Auxiliar).
    2. A integração do aluno em áreas específicas (Educação Física, Artes, etc).
    3. Recomendações pedagógicas para melhorar a autonomia do aluno e a clareza das instruções para o auxiliar.

    Responda obrigatoriamente em Português do Brasil com tom profissional e técnico.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });
    return response.text;
  } catch (error) {
    console.error("Erro na análise Gemini:", error);
    return "Não foi possível gerar a análise automática no momento.";
  }
};
