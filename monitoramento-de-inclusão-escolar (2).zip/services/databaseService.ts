
import { DailyLog } from "../types";

// Interface para o banco de dados
// Usaremos uma abordagem de persistência remota via API
export class DatabaseService {
  private static STORAGE_KEY = 'inclu_db_config';

  static getConfig() {
    const config = localStorage.getItem(this.STORAGE_KEY);
    return config ? JSON.parse(config) : null;
  }

  static setConfig(url: string, key: string) {
    localStorage.setItem(this.STORAGE_KEY, JSON.stringify({ url, key }));
  }

  // Busca todos os logs do banco de dados na nuvem
  static async fetchLogs(): Promise<DailyLog[]> {
    const config = this.getConfig();
    if (!config) return [];

    try {
      const response = await fetch(`${config.url}/rest/v1/logs?select=data`, {
        headers: {
          'apikey': config.key,
          'Authorization': `Bearer ${config.key}`
        }
      });
      const data = await response.json();
      return data.map((item: any) => item.data);
    } catch (error) {
      console.error("Erro ao buscar logs da nuvem:", error);
      return [];
    }
  }

  // Salva um novo log no banco de dados na nuvem
  static async saveLog(log: DailyLog): Promise<boolean> {
    const config = this.getConfig();
    if (!config) return false;

    try {
      const response = await fetch(`${config.url}/rest/v1/logs`, {
        method: 'POST',
        headers: {
          'apikey': config.key,
          'Authorization': `Bearer ${config.key}`,
          'Content-Type': 'application/json',
          'Prefer': 'return=minimal'
        },
        body: JSON.stringify({ id: log.id, data: log })
      });
      return response.ok;
    } catch (error) {
      console.error("Erro ao salvar log na nuvem:", error);
      return false;
    }
  }

  // Remove um log do banco de dados na nuvem
  static async deleteLog(id: string): Promise<boolean> {
    const config = this.getConfig();
    if (!config) return false;

    try {
      const response = await fetch(`${config.url}/rest/v1/logs?id=eq.${id}`, {
        method: 'DELETE',
        headers: {
          'apikey': config.key,
          'Authorization': `Bearer ${config.key}`
        }
      });
      return response.ok;
    } catch (error) {
      console.error("Erro ao excluir log na nuvem:", error);
      return false;
    }
  }
}
