
import React, { useState, useMemo } from 'react';
import { Student, DailyLog } from '../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { analyzeStudentProgress } from '../services/geminiService';
import { DatabaseService } from '../services/databaseService';

interface AdminViewProps {
  students: Student[];
  logs: DailyLog[];
  deleteLog: (id: string) => void;
}

const COLORS = ['#3B82F6', '#EF4444', '#10B981', '#F59E0B', '#8B5CF6'];

const AdminView: React.FC<AdminViewProps> = ({ students, logs, deleteLog }) => {
  const [activeTab, setActiveTab] = useState<'logs' | 'summary' | 'analysis' | 'settings'>('logs');
  const [selectedAnalysisStudent, setSelectedAnalysisStudent] = useState('');
  const [aiReport, setAiReport] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [selectedLog, setSelectedLog] = useState<DailyLog | null>(null);

  // Estados para Configuração do Supabase
  const currentConfig = DatabaseService.getConfig();
  const [dbUrl, setDbUrl] = useState(currentConfig?.url || '');
  const [dbKey, setDbKey] = useState(currentConfig?.key || '');
  const [saveStatus, setSaveStatus] = useState('');

  const stats = useMemo(() => {
    if (logs.length === 0) return null;
    
    const count = (predicate: (l: DailyLog) => boolean) => logs.filter(predicate).length;
    
    const subjectsCount: Record<string, number> = {};
    const refusalBehaviorCount: Record<string, number> = {};
    const helpLevels: Record<string, number> = {};
    const behaviorCounts: Record<string, number> = {};

    logs.forEach(l => {
      if (l.componentesCurriculares) {
        l.componentesCurriculares.split(', ').forEach(s => {
          if (s) subjectsCount[s] = (subjectsCount[s] || 0) + 1;
        });
      }
      if (l.houveRecusa && l.comportamentosRecusa) {
        l.comportamentosRecusa.split('; ').forEach(b => {
          if (b) refusalBehaviorCount[b] = (refusalBehaviorCount[b] || 0) + 1;
        });
      }
      const level = l.tipoAjuda || 'Independente';
      helpLevels[level] = (helpLevels[level] || 0) + 1;
      behaviorCounts[l.behavior] = (behaviorCounts[l.behavior] || 0) + 1;
    });

    return {
      total: logs.length,
      realizouAdaptadas: count(l => l.realizouAtividadesAdaptadas),
      houveRecusa: count(l => l.houveRecusa),
      dificuldadeAuxiliar: count(l => l.dificuldadeEntendimentoAuxiliar),
      participouEspecificas: count(l => l.participouAreasEspecificas),
      topSubjects: Object.entries(subjectsCount).sort((a, b) => b[1] - a[1]).slice(0, 5),
      topRefusals: Object.entries(refusalBehaviorCount).sort((a, b) => b[1] - a[1]).slice(0, 5),
      helpDistribution: Object.entries(helpLevels).map(([name, value]) => ({ name, value })),
      behaviorData: Object.entries(behaviorCounts).map(([name, value]) => ({ name, value }))
    };
  }, [logs]);

  const handleRunAnalysis = async () => {
    if (!selectedAnalysisStudent) return;
    setIsAnalyzing(true);
    const student = students.find(s => s.id === selectedAnalysisStudent);
    const studentLogs = logs.filter(l => l.studentId === selectedAnalysisStudent);
    
    if (student) {
      const report = await analyzeStudentProgress(studentLogs, student);
      setAiReport(report || "Sem dados suficientes para gerar análise.");
    }
    setIsAnalyzing(false);
  };

  const handleDelete = (id: string) => {
    if (window.confirm("Tem certeza que deseja excluir este registro permanentemente?")) {
      deleteLog(id);
      if (selectedLog?.id === id) setSelectedLog(null);
    }
  };

  const handleSaveConfig = (e: React.FormEvent) => {
    e.preventDefault();
    DatabaseService.setConfig(dbUrl, dbKey);
    setSaveStatus('Configuração salva! Recarregue a página para ativar.');
    setTimeout(() => setSaveStatus(''), 5000);
  };

  return (
    <div className="space-y-6">
      <div className="flex space-x-2 border-b border-gray-200 overflow-x-auto pb-1 scrollbar-hide">
        {[
          { id: 'logs', label: 'Todos os Registros' },
          { id: 'summary', label: 'Resumo de Dados' },
          { id: 'analysis', label: 'Análise por IA' },
          { id: 'settings', label: 'Conexão Banco' }
        ].map(tab => (
          <button 
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`px-4 py-2 font-bold text-sm transition-all whitespace-nowrap rounded-t-lg ${activeTab === tab.id ? 'bg-blue-600 text-white' : 'text-gray-500 hover:bg-gray-100'}`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {activeTab === 'logs' && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
          <div className="p-4 bg-gray-50 border-b flex justify-between items-center">
            <h3 className="font-bold text-gray-800">Banco de Dados de Inclusão</h3>
            <span className="text-xs font-medium bg-blue-100 text-blue-700 px-2 py-1 rounded-full uppercase">
              {logs.length} Registros
            </span>
          </div>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase">Data Atividade</th>
                  <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase">Aluno</th>
                  <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase">Comportamento</th>
                  <th className="px-6 py-3 text-right text-xs font-bold text-gray-500 uppercase">Ações</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {logs.map((log) => (
                  <tr key={log.id} className="hover:bg-gray-50 transition-colors group">
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">{log.date}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-bold text-gray-900">
                      {students.find(s => s.id === log.studentId)?.name}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 py-1 text-[10px] font-bold rounded-full uppercase ${
                        log.behavior === 'excelente' ? 'bg-green-100 text-green-800' :
                        log.behavior === 'bom' ? 'bg-blue-100 text-blue-800' :
                        log.behavior === 'regular' ? 'bg-yellow-100 text-yellow-800' : 'bg-red-100 text-red-800'
                      }`}>
                        {log.behavior}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium space-x-3">
                      <button 
                        onClick={() => setSelectedLog(log)}
                        className="text-blue-600 hover:text-blue-900 font-bold"
                      >
                        Ver Detalhes
                      </button>
                      <button 
                        onClick={() => handleDelete(log.id)}
                        className="text-red-500 hover:text-red-700 font-bold"
                      >
                        Excluir
                      </button>
                    </td>
                  </tr>
                ))}
                {logs.length === 0 && (
                  <tr><td colSpan={4} className="px-6 py-20 text-center text-gray-400 font-medium">Nenhum registro encontrado.</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {activeTab === 'summary' && stats && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="bg-white p-6 rounded-xl border shadow-sm">
            <p className="text-gray-500 text-xs font-bold uppercase mb-2">Atividades Adaptadas</p>
            <div className="flex items-end justify-between">
              <span className="text-3xl font-extrabold text-blue-600">{Math.round((stats.realizouAdaptadas/stats.total)*100)}%</span>
              <span className="text-sm text-gray-400">{stats.realizouAdaptadas} / {stats.total}</span>
            </div>
            <div className="w-full bg-gray-100 h-2 rounded-full mt-3">
              <div className="bg-blue-600 h-full rounded-full" style={{ width: `${(stats.realizouAdaptadas/stats.total)*100}%` }}></div>
            </div>
          </div>
          <div className="bg-white p-6 rounded-xl border shadow-sm">
            <p className="text-gray-500 text-xs font-bold uppercase mb-2">Houve Recusa</p>
            <div className="flex items-end justify-between">
              <span className="text-3xl font-extrabold text-red-500">{Math.round((stats.houveRecusa/stats.total)*100)}%</span>
              <span className="text-sm text-gray-400">{stats.houveRecusa} casos</span>
            </div>
            <div className="w-full bg-gray-100 h-2 rounded-full mt-3">
              <div className="bg-red-500 h-full rounded-full" style={{ width: `${(stats.houveRecusa/stats.total)*100}%` }}></div>
            </div>
          </div>
          <div className="bg-white p-6 rounded-xl border shadow-sm">
            <p className="text-gray-500 text-xs font-bold uppercase mb-2">Dificuldade Auxiliar</p>
            <div className="flex items-end justify-between">
              <span className="text-3xl font-extrabold text-orange-500">{Math.round((stats.dificuldadeAuxiliar/stats.total)*100)}%</span>
              <span className="text-sm text-gray-400">{stats.dificuldadeAuxiliar} logs</span>
            </div>
            <div className="w-full bg-gray-100 h-2 rounded-full mt-3">
              <div className="bg-orange-500 h-full rounded-full" style={{ width: `${(stats.dificuldadeAuxiliar/stats.total)*100}%` }}></div>
            </div>
          </div>
          <div className="bg-white p-6 rounded-xl border shadow-sm">
            <p className="text-gray-500 text-xs font-bold uppercase mb-2">Áreas Específicas</p>
            <div className="flex items-end justify-between">
              <span className="text-3xl font-extrabold text-green-600">{Math.round((stats.participouEspecificas/stats.total)*100)}%</span>
              <span className="text-sm text-gray-400">{stats.participouEspecificas} logs</span>
            </div>
            <div className="w-full bg-gray-100 h-2 rounded-full mt-3">
              <div className="bg-green-600 h-full rounded-full" style={{ width: `${(stats.participouEspecificas/stats.total)*100}%` }}></div>
            </div>
          </div>

          <div className="md:col-span-2 bg-white p-6 rounded-xl border shadow-sm">
            <h4 className="font-bold text-gray-800 mb-4 border-b pb-2">Top 5 Comportamentos de Recusa</h4>
            <div className="space-y-4">
              {stats.topRefusals.map(([name, count]) => (
                <div key={name}>
                  <div className="flex justify-between text-xs font-bold text-gray-600 mb-1">
                    <span>{name}</span>
                    <span>{count} ocorrências</span>
                  </div>
                  <div className="w-full bg-gray-100 h-2 rounded-full overflow-hidden">
                    <div className="bg-red-400 h-full" style={{ width: `${(count/stats.total)*100}%` }}></div>
                  </div>
                </div>
              ))}
              {stats.topRefusals.length === 0 && <p className="text-center text-gray-400 py-10">Nenhuma recusa registrada.</p>}
            </div>
          </div>

          <div className="md:col-span-2 bg-white p-6 rounded-xl border shadow-sm">
            <h4 className="font-bold text-gray-800 mb-4 border-b pb-2">Nível de Ajuda Fornecido</h4>
            <div className="h-48">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={stats.helpDistribution}
                    innerRadius={40}
                    outerRadius={60}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {stats.helpDistribution.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="grid grid-cols-2 gap-x-4 gap-y-1 mt-2">
              {stats.helpDistribution.map((entry, index) => (
                <div key={entry.name} className="flex items-center space-x-2">
                  <div className="w-2 h-2 rounded-full flex-shrink-0" style={{ backgroundColor: COLORS[index % COLORS.length] }}></div>
                  <span className="text-[10px] text-gray-600 truncate">{entry.name}: {entry.value}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="md:col-span-4 bg-white p-6 rounded-xl border shadow-sm">
            <h4 className="font-bold text-gray-800 mb-4 border-b pb-2">Comportamento Geral das Aulas</h4>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={stats.behaviorData}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="value" fill="#8B5CF6" radius={[4, 4, 0, 0]} name="Ocorrências" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'analysis' && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="md:col-span-1 bg-white p-6 rounded-xl shadow-sm border h-fit space-y-4">
            <h3 className="font-bold text-gray-800">Análise Inteligente</h3>
            <p className="text-xs text-gray-500">Gere insights pedagógicos baseados no histórico de registros diários.</p>
            <select
              className="w-full px-4 py-2 border rounded-lg text-sm bg-gray-50"
              value={selectedAnalysisStudent}
              onChange={(e) => setSelectedAnalysisStudent(e.target.value)}
            >
              <option value="">Escolha um aluno...</option>
              {students.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
            <button
              onClick={handleRunAnalysis}
              disabled={!selectedAnalysisStudent || isAnalyzing}
              className="w-full bg-indigo-600 text-white py-2 rounded-lg font-bold hover:bg-indigo-700 disabled:bg-gray-300 transition-all shadow-sm"
            >
              {isAnalyzing ? 'Analisando...' : 'Iniciar Análise IA'}
            </button>
          </div>
          <div className="md:col-span-3 bg-white p-8 rounded-xl border shadow-sm min-h-[400px]">
            {aiReport ? (
              <div className="animate-fadeIn">
                <h2 className="text-xl font-bold text-indigo-700 mb-6 flex items-center">
                  <svg className="h-6 w-6 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
                  </svg>
                  Recomendações Gemini (AEE)
                </h2>
                <div className="bg-indigo-50 p-6 rounded-2xl border border-indigo-100 text-gray-700 text-sm leading-relaxed whitespace-pre-wrap shadow-inner">
                  {aiReport}
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-full text-gray-400 opacity-60">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-20 w-20 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
                <p className="font-bold text-center">Selecione um aluno para gerar as recomendações automáticas.</p>
              </div>
            )}
          </div>
        </div>
      )}

      {activeTab === 'settings' && (
        <div className="max-w-xl mx-auto bg-white p-8 rounded-2xl border shadow-sm space-y-6">
          <div className="text-center">
            <h3 className="text-xl font-bold text-gray-800">Sincronização com Nuvem (Supabase)</h3>
            <p className="text-sm text-gray-500 mt-2">Configure aqui as chaves do seu banco de dados para que Sarah e Raphael vejam os mesmos dados.</p>
          </div>
          
          <form onSubmit={handleSaveConfig} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Project URL</label>
              <input 
                type="text" 
                className="w-full px-4 py-2 border rounded-lg text-sm bg-gray-50"
                placeholder="https://suaprojeto.supabase.co"
                value={dbUrl}
                onChange={e => setDbUrl(e.target.value)}
                required
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Anon API Key</label>
              <input 
                type="password" 
                className="w-full px-4 py-2 border rounded-lg text-sm bg-gray-50"
                placeholder="Sua Chave Anon"
                value={dbKey}
                onChange={e => setDbKey(e.target.value)}
                required
              />
            </div>
            
            {saveStatus && (
              <div className="p-3 bg-green-50 text-green-700 text-xs rounded-lg border border-green-100 font-bold">
                {saveStatus}
              </div>
            )}

            <button type="submit" className="w-full bg-blue-600 text-white py-3 rounded-xl font-bold hover:bg-blue-700 transition-all">
              Salvar e Conectar
            </button>
          </form>

          <div className="bg-blue-50 p-4 rounded-xl text-[11px] text-blue-700 space-y-2">
            <p className="font-bold">Como funciona?</p>
            <p>1. Crie uma conta no <a href="https://supabase.com" target="_blank" className="underline">Supabase</a>.</p>
            <p>2. Crie a tabela 'logs' no SQL Editor.</p>
            <p>3. Cole as chaves acima.</p>
            <p>4. Agora Raphael (no celular/PC dele) e você (Sarah) estarão conectados ao mesmo banco de dados.</p>
          </div>
        </div>
      )}

      {selectedLog && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50 animate-fadeIn overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-2xl w-full p-6 shadow-2xl space-y-4 my-8">
            <div className="flex justify-between items-start border-b pb-4">
              <div>
                <h2 className="text-xl font-bold text-gray-800">
                  Relatório: {students.find(s => s.id === selectedLog.studentId)?.name}
                </h2>
                <p className="text-sm text-gray-500">Data Atividade: {selectedLog.date} | Auxiliar: {selectedLog.assistantId}</p>
              </div>
              <div className="flex space-x-2">
                <button 
                  onClick={() => handleDelete(selectedLog.id)}
                  className="bg-red-50 text-red-600 p-2 rounded-lg hover:bg-red-100"
                  title="Excluir Registro"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                  </svg>
                </button>
                <button onClick={() => setSelectedLog(null)} className="text-gray-400 hover:text-gray-600">
                  <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
              <div className="bg-gray-50 p-4 rounded-xl border border-blue-100">
                <p className="font-bold text-blue-700 mb-2 uppercase text-[10px] tracking-widest">Pedagogia</p>
                <ul className="space-y-2">
                  <li className="flex justify-between"><span>Atividades Adaptadas:</span> <span className="font-bold">{selectedLog.realizouAtividadesAdaptadas ? 'Sim' : 'Não'}</span></li>
                  {selectedLog.realizouAtividadesAdaptadas && (
                    <li className="text-xs text-gray-500 italic">{selectedLog.componentesCurriculares}</li>
                  )}
                  <li className="flex justify-between"><span>Tipo de Ajuda:</span> <span className="font-bold">{selectedLog.tipoAjuda || 'Independente'}</span></li>
                  <li className="flex justify-between"><span>Dif. Auxiliar:</span> <span className={`font-bold ${selectedLog.dificuldadeEntendimentoAuxiliar ? 'text-red-500' : 'text-green-600'}`}>{selectedLog.dificuldadeEntendimentoAuxiliar ? 'Sim' : 'Não'}</span></li>
                </ul>
              </div>
              <div className="bg-gray-50 p-4 rounded-xl border border-purple-100">
                <p className="font-bold text-purple-700 mb-2 uppercase text-[10px] tracking-widest">Desenvolvimento</p>
                <ul className="space-y-2">
                  <li className="flex justify-between"><span>Comportamento:</span> <span className="font-bold uppercase text-[10px]">{selectedLog.behavior}</span></li>
                  <li className="flex justify-between"><span>Áreas Específicas:</span> <span className="font-bold">{selectedLog.participouAreasEspecificas ? 'Sim' : 'Não'}</span></li>
                  {selectedLog.participouAreasEspecificas && (
                    <li className="text-xs text-gray-500 italic">{selectedLog.areasEspecificasDetalhadas}</li>
                  )}
                  <li className="flex justify-between"><span>Houve Recusa?</span> <span className={`font-bold ${selectedLog.houveRecusa ? 'text-red-500' : 'text-green-600'}`}>{selectedLog.houveRecusa ? 'Sim' : 'Não'}</span></li>
                  {selectedLog.houveRecusa && (
                    <li className="text-[10px] text-red-600 bg-red-50 p-1 rounded"><strong>Motivos:</strong> {selectedLog.comportamentosRecusa}</li>
                  )}
                </ul>
              </div>
            </div>

            <div className="bg-white p-4 rounded-xl border">
              <p className="font-bold text-gray-700 text-sm mb-2">Descrição das Atividades:</p>
              <p className="text-sm text-gray-600 leading-relaxed italic">"{selectedLog.activitiesDone}"</p>
            </div>

            <button 
              onClick={() => setSelectedLog(null)}
              className="w-full bg-blue-600 text-white py-3 rounded-xl font-bold hover:bg-blue-700 transition-all shadow-md"
            >
              Fechar Visualização
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminView;
