
import React from 'react';
import { User, UserRole } from '../types';

interface NavbarProps {
  user: User;
  onLogout: () => void;
  isOnline: boolean;
  isSyncing: boolean;
  onRefresh: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ user, onLogout, isOnline, isSyncing, onRefresh }) => {
  return (
    <nav className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center space-x-3">
            <div className="bg-blue-600 p-2 rounded-lg text-white">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
              </svg>
            </div>
            <span className="text-xl font-black text-gray-800 tracking-tight hidden sm:block">IncluDaily</span>
          </div>
          
          <div className="flex items-center space-x-4">
            {/* Status de Sincronização */}
            <div className="flex items-center space-x-2 px-3 py-1 bg-gray-50 rounded-full border border-gray-200">
              <div className={`h-2 w-2 rounded-full ${isSyncing ? 'bg-blue-400 animate-pulse' : (isOnline ? 'bg-green-500' : 'bg-gray-300')}`}></div>
              <span className="text-[10px] font-bold text-gray-500 uppercase tracking-widest hidden md:block">
                {isSyncing ? 'Sincronizando...' : (isOnline ? 'Nuvem Conectada' : 'Modo Local')}
              </span>
              <button 
                onClick={onRefresh}
                className={`p-1 hover:text-blue-600 transition-colors ${isSyncing ? 'animate-spin' : ''}`}
                title="Sincronizar agora"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                </svg>
              </button>
            </div>

            <div className="text-right hidden sm:block">
              <p className="text-sm font-bold text-gray-800 leading-none">{user.name}</p>
              <p className="text-[10px] text-gray-500 uppercase font-black tracking-tighter">
                {user.role === UserRole.ADMIN ? 'Administradora' : 'Auxiliar de Apoio'}
              </p>
            </div>

            <div className="flex items-center space-x-2 border-l pl-4 border-gray-100">
              <button
                onClick={onLogout}
                className="p-2 rounded-xl hover:bg-red-50 text-gray-400 hover:text-red-500 transition-all"
                title="Sair do Sistema"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                </svg>
              </button>
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
