
import React from 'react';
import { User, UserRole, Student, DailyLog } from '../types';
import AssistantView from './AssistantView';
import AdminView from './AdminView';

interface DashboardProps {
  user: User;
  students: Student[];
  logs: DailyLog[];
  addLog: (log: DailyLog) => void;
  deleteLog: (id: string) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ user, students, logs, addLog, deleteLog }) => {
  return (
    <div>
      {user.role === UserRole.ADMIN ? (
        <AdminView 
          students={students} 
          logs={logs} 
          deleteLog={deleteLog}
        />
      ) : (
        <AssistantView 
          user={user} 
          students={students} 
          logs={logs} 
          addLog={addLog} 
        />
      )}
    </div>
  );
};

export default Dashboard;
