
import React, { useState } from 'react';
import { User, UserRole } from '../types';

interface LoginProps {
  onLogin: (user: User) => void;
}

const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const lowerUsername = username.toLowerCase();

    // AUTENTICAÇÃO SIMULADA
    if (lowerUsername === 'sarah' && password === '1234') {
      onLogin({ 
        id: 'admin-sarah', 
        username: 'Sarah', 
        name: 'Sarah (Administradora)', 
        role: UserRole.ADMIN 
      });
    } else if (lowerUsername === 'admin' && password === '123') {
      onLogin({ 
        id: 'admin-1', 
        username: 'admin', 
        name: 'Coordenador(a) Geral', 
        role: UserRole.ADMIN 
      });
    } else if (lowerUsername === 'auxiliar' && password === '123') {
      onLogin({ 
        id: 'aux-1', 
        username: 'auxiliar', 
        name: 'Auxiliar de Apoio', 
        role: UserRole.ASSISTANT 
      });
    } else if (lowerUsername === 'raphael' && password === '123') {
      onLogin({ 
        id: 'aux-raphael', 
        username: 'Raphael', 
        name: 'Raphael (Estagiário)', 
        role: UserRole.ASSISTANT 
      });
    } else {
      setError('Credenciais inválidas. Verifique seus dados e tente novamente.');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-600 to-indigo-800 p-4">
      <div className="bg-white p-8 rounded-2xl shadow-2xl w-full max-w-md border border-white/20">
        <div className="text-center mb-8">
          <div className="inline-block p-4 rounded-full bg-blue-50 text-blue-600 mb-4 shadow-inner">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
            </svg>
          </div>
          <h1 className="text-3xl font-extrabold text-gray-900 tracking-tight">IncluDaily</h1>
          <p className="text-gray-500 font-medium">Gestão Diária de Inclusão AEE</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label className="block text-xs font-bold text-gray-700 uppercase mb-1 ml-1">Usuário</label>
            <input
              type="text"
              required
              className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all outline-none text-gray-800"
              placeholder="Ex: admin, auxiliar ou raphael"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
            />
          </div>
          <div>
            <label className="block text-xs font-bold text-gray-700 uppercase mb-1 ml-1">Senha</label>
            <input
              type="password"
              required
              className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all outline-none text-gray-800"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>
          {error && (
            <div className="p-3 bg-red-50 text-red-600 text-xs rounded-xl border border-red-100 text-center font-bold animate-shake">
              {error}
            </div>
          )}
          <button
            type="submit"
            className="w-full py-4 px-4 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl transition-all shadow-lg hover:shadow-blue-200 active:scale-95"
          >
            Acessar Sistema
          </button>
        </form>
        
        <div className="mt-8 pt-6 border-t border-gray-100 text-center text-[10px] text-gray-400 font-bold uppercase tracking-widest">
          <p>© 2024 Monitoramento Pedagógico Especializado</p>
        </div>
      </div>
    </div>
  );
};

export default Login;
