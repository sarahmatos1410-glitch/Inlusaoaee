
import React, { useState } from 'react';
import { User, Student, DailyLog } from '../types';

interface AssistantViewProps {
  user: User;
  students: Student[];
  logs: DailyLog[];
  addLog: (log: DailyLog) => void;
}

const COMPONENTES_LISTA = [
  'Língua Portuguesa',
  'Literatura',
  'Produção Textual',
  'Matemática',
  'História',
  'Geografia',
  'Ciências',
  'Biologia',
  'Física',
  'Química',
  'Arte',
  'Língua Inglesa',
  'Ensino Religioso',
  'Projeto de Vida'
];

const AREAS_ESPECIFICAS_LISTA = [
  'Educação Física',
  'Artes',
  'Música',
  'Informática / Robótica',
  'Biblioteca / Leitura',
  'Laboratório',
  'AEE (Sala de Recursos)',
  'Outro'
];

const HELP_TYPES = [
  { id: 'ajuda_leve', label: 'Ajuda leve' },
  { id: 'ajuda_parcial', label: 'Ajuda parcial' },
  { id: 'ajuda_fisica_total', label: 'Ajuda física total' },
  { id: 'ajuda_gestual', label: 'Ajuda gestual' },
  { id: 'ajuda_verbal_parcial', label: 'Ajuda verbal parcial' },
  { id: 'ajuda_verbal_total', label: 'Ajuda verbal total' }
];

const COMPORTAMENTOS_RECUSA_OPCOES = [
  'Rasgou a atividade',
  'Jogou a atividade no chão',
  'Quebrou a ponta do lápis',
  'Esquivou-se da demanda'
];

const AssistantView: React.FC<AssistantViewProps> = ({ user, students, logs, addLog }) => {
  const [selectedStudent, setSelectedStudent] = useState('');
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [behavior, setBehavior] = useState<DailyLog['behavior']>('bom');
  const [activities, setActivities] = useState('');
  const [notes, setNotes] = useState('');
  
  // Estados para o formulário detalhado
  const [realizouAdaptadas, setRealizouAdaptadas] = useState<string>('nao');
  const [componentesSelecionados, setComponentesSelecionados] = useState<string[]>([]);
  const [comAjuda, setComAjuda] = useState<string>('nao');
  const [tipoAjuda, setTipoAjuda] = useState<string>('');
  const [houveRecusa, setHouveRecusa] = useState<string>('nao');
  const [recusasSelecionadas, setRecusasSelecionadas] = useState<string[]>([]);
  const [outrosComportamentosRecusa, setOutrosComportamentosRecusa] = useState('');

  // Novos estados para as perguntas finais
  const [dificuldadeAuxiliar, setDificuldadeAuxiliar] = useState<string>('nao');
  const [participouEspecificas, setParticipouEspecificas] = useState<string>('nao');
  const [areasEspecificasSelecionadas, setAreasEspecificasSelecionadas] = useState<string[]>([]);
  
  const [success, setSuccess] = useState(false);

  const toggleList = (item: string, list: string[], setList: (val: string[]) => void) => {
    setList(list.includes(item) ? list.filter(i => i !== item) : [...list, item]);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedStudent || !selectedDate) return;

    const formattedDate = new Date(selectedDate + 'T12:00:00').toLocaleDateString('pt-BR');

    // Combina recusas pré-definidas com texto livre
    const comportamentosFinais = [
      ...recusasSelecionadas,
      ...(outrosComportamentosRecusa ? [outrosComportamentosRecusa] : [])
    ].join('; ');

    const newLog: DailyLog = {
      id: Math.random().toString(36).substr(2, 9),
      date: formattedDate,
      studentId: selectedStudent,
      assistantId: user.id,
      behavior,
      realizouAtividadesAdaptadas: realizouAdaptadas === 'sim',
      componentesCurriculares: componentesSelecionados.join(', '),
      metodoRealizacao: comAjuda === 'sim' ? 'com_ajuda' : 'sozinho',
      tipoAjuda: comAjuda === 'sim' ? tipoAjuda : '',
      houveRecusa: houveRecusa === 'sim',
      comportamentosRecusa: houveRecusa === 'sim' ? comportamentosFinais : '',
      
      dificuldadeEntendimentoAuxiliar: dificuldadeAuxiliar === 'sim',
      participouAreasEspecificas: participouEspecificas === 'sim',
      areasEspecificasDetalhadas: areasEspecificasSelecionadas.join(', '),

      activitiesDone: activities,
      notes,
      timestamp: new Date(selectedDate).getTime(),
    };

    addLog(newLog);
    setSuccess(true);
    
    // Resetar campos
    setActivities('');
    setNotes('');
    setComponentesSelecionados([]);
    setAreasEspecificasSelecionadas([]);
    setRecusasSelecionadas([]);
    setOutrosComportamentosRecusa('');
    setRealizouAdaptadas('nao');
    setHouveRecusa('nao');
    setComAjuda('nao');
    setTipoAjuda('');
    setDificuldadeAuxiliar('nao');
    setParticipouEspecificas('nao');
    
    setTimeout(() => setSuccess(false), 3000);
  };

  const assistantLogs = logs.filter(l => l.assistantId === user.id).slice(0, 5);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      <div className="lg:col-span-2 space-y-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
          <div className="bg-blue-600 px-6 py-4">
            <h2 className="text-xl font-bold text-white flex items-center">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
              </svg>
              Novo Registro de AEE
            </h2>
          </div>
          <form onSubmit={handleSubmit} className="p-6 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Data da Atividade</label>
                <input
                  type="date"
                  required
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                  value={selectedDate}
                  onChange={(e) => setSelectedDate(e.target.value)}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Aluno(a)</label>
                <select
                  required
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                  value={selectedStudent}
                  onChange={(e) => setSelectedStudent(e.target.value)}
                >
                  <option value="">Selecione o aluno...</option>
                  {students.map(s => <option key={s.id} value={s.id}>{s.name} - {s.grade}</option>)}
                </select>
              </div>
            </div>

            <div className="bg-gray-50 p-4 rounded-xl border border-gray-200 space-y-4">
              <h3 className="font-bold text-gray-700 text-sm border-b pb-2 flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1 text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                </svg>
                Desenvolvimento Pedagógico
              </h3>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">O aluno resolveu e realizou atividades adaptadas?</label>
                <div className="flex space-x-6">
                  <label className="flex items-center cursor-pointer group">
                    <input
                      type="radio"
                      name="realizouAdaptadas"
                      value="sim"
                      checked={realizouAdaptadas === 'sim'}
                      onChange={(e) => setRealizouAdaptadas(e.target.value)}
                      className="h-4 w-4 text-blue-600"
                    />
                    <span className="ml-2 text-sm font-medium text-gray-700 group-hover:text-blue-600 transition-colors">Sim</span>
                  </label>
                  <label className="flex items-center cursor-pointer group">
                    <input
                      type="radio"
                      name="realizouAdaptadas"
                      value="nao"
                      checked={realizouAdaptadas === 'nao'}
                      onChange={(e) => setRealizouAdaptadas(e.target.value)}
                      className="h-4 w-4 text-blue-600"
                    />
                    <span className="ml-2 text-sm font-medium text-gray-700 group-hover:text-blue-600 transition-colors">Não</span>
                  </label>
                </div>
              </div>

              {realizouAdaptadas === 'sim' && (
                <div className="animate-fadeIn space-y-4 bg-white p-5 rounded-lg border border-gray-200 shadow-sm">
                  <div>
                    <label className="block text-xs font-bold text-gray-500 uppercase mb-3 tracking-wider">Componentes Curriculares:</label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                      {COMPONENTES_LISTA.map((comp) => (
                        <label key={comp} className="flex items-center space-x-2 p-2 rounded hover:bg-blue-50 cursor-pointer transition-colors border border-transparent hover:border-blue-100">
                          <input
                            type="checkbox"
                            className="h-4 w-4 text-blue-600 rounded focus:ring-blue-500"
                            checked={componentesSelecionados.includes(comp)}
                            onChange={() => toggleList(comp, componentesSelecionados, setComponentesSelecionados)}
                          />
                          <span className="text-sm text-gray-700">{comp}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              <div className="pt-2">
                <label className="block text-sm font-medium text-gray-700 mb-2">A realização da atividade foi feita com ajuda?</label>
                <div className="flex space-x-6">
                  <label className="flex items-center cursor-pointer group">
                    <input
                      type="radio"
                      name="comAjuda"
                      value="sim"
                      checked={comAjuda === 'sim'}
                      onChange={(e) => setComAjuda(e.target.value)}
                      className="h-4 w-4 text-blue-600"
                    />
                    <span className="ml-2 text-sm font-medium text-gray-700 group-hover:text-blue-600 transition-colors">Sim</span>
                  </label>
                  <label className="flex items-center cursor-pointer group">
                    <input
                      type="radio"
                      name="comAjuda"
                      value="nao"
                      checked={comAjuda === 'nao'}
                      onChange={(e) => setComAjuda(e.target.value)}
                      className="h-4 w-4 text-blue-600"
                    />
                    <span className="ml-2 text-sm font-medium text-gray-700 group-hover:text-blue-600 transition-colors">Não (Independente)</span>
                  </label>
                </div>

                {comAjuda === 'sim' && (
                  <div className="mt-4 animate-fadeIn bg-white p-4 rounded-lg border border-gray-200 shadow-sm">
                    <label className="block text-xs font-bold text-gray-500 uppercase mb-3 tracking-wider">Selecione o tipo de ajuda:</label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {HELP_TYPES.map((type) => (
                        <label key={type.id} className="flex items-center space-x-2 p-2 rounded hover:bg-gray-50 cursor-pointer">
                          <input
                            type="radio"
                            name="tipoAjudaDetalhada"
                            value={type.label}
                            checked={tipoAjuda === type.label}
                            onChange={(e) => setTipoAjuda(e.target.value)}
                            className="h-4 w-4 text-blue-600"
                          />
                          <span className="text-sm text-gray-700">{type.label}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              <div className="pt-2">
                <label className="block text-sm font-medium text-gray-700 mb-2">Houve recusa do aluno?</label>
                <div className="flex space-x-6">
                  <label className="flex items-center cursor-pointer group">
                    <input
                      type="radio"
                      name="houveRecusa"
                      value="sim"
                      checked={houveRecusa === 'sim'}
                      onChange={(e) => setHouveRecusa(e.target.value)}
                      className="h-4 w-4 text-red-600"
                    />
                    <span className="ml-2 text-sm font-medium text-gray-700 group-hover:text-red-600 transition-colors">Sim</span>
                  </label>
                  <label className="flex items-center cursor-pointer group">
                    <input
                      type="radio"
                      name="houveRecusa"
                      value="nao"
                      checked={houveRecusa === 'nao'}
                      onChange={(e) => setHouveRecusa(e.target.value)}
                      className="h-4 w-4 text-red-600"
                    />
                    <span className="ml-2 text-sm font-medium text-gray-700 group-hover:text-red-600 transition-colors">Não</span>
                  </label>
                </div>
                
                {houveRecusa === 'sim' && (
                  <div className="mt-2 animate-fadeIn bg-white p-5 rounded-lg border border-red-100 shadow-sm space-y-4">
                    <div>
                      <label className="block text-xs font-bold text-gray-500 uppercase mb-3 tracking-wider">Comportamentos observados:</label>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-4">
                        {COMPORTAMENTOS_RECUSA_OPCOES.map((recusa) => (
                          <label key={recusa} className="flex items-center space-x-2 p-2 rounded hover:bg-red-50 cursor-pointer transition-colors border border-transparent hover:border-red-100">
                            <input
                              type="checkbox"
                              className="h-4 w-4 text-red-600 rounded focus:ring-red-500"
                              checked={recusasSelecionadas.includes(recusa)}
                              onChange={() => toggleList(recusa, recusasSelecionadas, setRecusasSelecionadas)}
                            />
                            <span className="text-sm text-gray-700">{recusa}</span>
                          </label>
                        ))}
                      </div>
                    </div>
                    
                    <div>
                      <label className="block text-xs font-bold text-gray-500 uppercase mb-2 tracking-wider">Outros comportamentos ou detalhes:</label>
                      <textarea
                        placeholder="Ex: Gritou, saiu correndo, etc..."
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm bg-gray-50 focus:bg-white transition-all outline-none"
                        rows={2}
                        value={outrosComportamentosRecusa}
                        onChange={(e) => setOutrosComportamentosRecusa(e.target.value)}
                      ></textarea>
                    </div>
                  </div>
                )}
              </div>

              <div className="pt-4 border-t border-gray-200 space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">A atividade foi difícil para o entendimento do auxiliar?</label>
                  <div className="flex space-x-6">
                    <label className="flex items-center cursor-pointer group">
                      <input
                        type="radio"
                        name="dificuldadeAuxiliar"
                        value="sim"
                        checked={dificuldadeAuxiliar === 'sim'}
                        onChange={(e) => setDificuldadeAuxiliar(e.target.value)}
                        className="h-4 w-4 text-blue-600"
                      />
                      <span className="ml-2 text-sm font-medium text-gray-700 group-hover:text-blue-600 transition-colors">Sim</span>
                    </label>
                    <label className="flex items-center cursor-pointer group">
                      <input
                        type="radio"
                        name="dificuldadeAuxiliar"
                        value="nao"
                        checked={dificuldadeAuxiliar === 'nao'}
                        onChange={(e) => setDificuldadeAuxiliar(e.target.value)}
                        className="h-4 w-4 text-blue-600"
                      />
                      <span className="ml-2 text-sm font-medium text-gray-700 group-hover:text-blue-600 transition-colors">Não</span>
                    </label>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Participação em áreas específicas hoje?</label>
                  <div className="flex space-x-6">
                    <label className="flex items-center cursor-pointer group">
                      <input
                        type="radio"
                        name="participouEspecificas"
                        value="sim"
                        checked={participouEspecificas === 'sim'}
                        onChange={(e) => setParticipouEspecificas(e.target.value)}
                        className="h-4 w-4 text-blue-600"
                      />
                      <span className="ml-2 text-sm font-medium text-gray-700 group-hover:text-blue-600 transition-colors">Sim</span>
                    </label>
                    <label className="flex items-center cursor-pointer group">
                      <input
                        type="radio"
                        name="participouEspecificas"
                        value="nao"
                        checked={participouEspecificas === 'nao'}
                        onChange={(e) => setParticipouEspecificas(e.target.value)}
                        className="h-4 w-4 text-blue-600"
                      />
                      <span className="ml-2 text-sm font-medium text-gray-700 group-hover:text-blue-600 transition-colors">Não</span>
                    </label>
                  </div>
                </div>

                {participouEspecificas === 'sim' && (
                  <div className="animate-fadeIn space-y-4 bg-white p-5 rounded-lg border border-gray-200 shadow-sm">
                    <label className="block text-xs font-bold text-gray-500 uppercase mb-3 tracking-wider">Aulas assistidas:</label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {AREAS_ESPECIFICAS_LISTA.map((area) => (
                        <label key={area} className="flex items-center space-x-2 p-2 rounded hover:bg-blue-50 cursor-pointer transition-colors border border-transparent hover:border-blue-100">
                          <input
                            type="checkbox"
                            className="h-4 w-4 text-blue-600 rounded focus:ring-blue-500"
                            checked={areasEspecificasSelecionadas.includes(area)}
                            onChange={() => toggleList(area, areasEspecificasSelecionadas, setAreasEspecificasSelecionadas)}
                          />
                          <span className="text-sm text-gray-700">{area}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Comportamento Geral</label>
              <div className="flex flex-wrap gap-2">
                {['excelente', 'bom', 'regular', 'dificil'].map((lvl) => (
                  <button
                    key={lvl}
                    type="button"
                    onClick={() => setBehavior(lvl as any)}
                    className={`px-4 py-2 rounded-lg border text-sm font-bold transition-all ${
                      behavior === lvl 
                        ? 'bg-blue-600 text-white border-blue-600 shadow-md transform scale-105' 
                        : 'bg-white text-gray-600 border-gray-200 hover:border-blue-300'
                    }`}
                  >
                    {lvl.charAt(0).toUpperCase() + lvl.slice(1)}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Descrição Detalhada das Atividades</label>
              <textarea
                required
                rows={4}
                placeholder="Ex: Realizamos atividades de contagem usando blocos lógicos..."
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 transition-all text-sm outline-none"
                value={activities}
                onChange={(e) => setActivities(e.target.value)}
              ></textarea>
            </div>

            {success && (
              <div className="p-4 bg-green-50 text-green-700 rounded-lg flex items-center border border-green-200">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
                Relatório diário registrado com sucesso!
              </div>
            )}

            <button
              type="submit"
              className="w-full bg-blue-600 text-white py-4 px-6 rounded-lg font-bold hover:bg-blue-700 transition-all shadow-lg active:transform active:scale-95 text-lg"
            >
              Salvar Registro de AEE
            </button>
          </form>
        </div>
      </div>

      <div className="space-y-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <h3 className="text-lg font-bold text-gray-800 mb-4 border-b pb-2 flex items-center">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            Meus Registros Recentes
          </h3>
          {assistantLogs.length === 0 ? (
            <p className="text-gray-400 text-sm italic">Nenhum registro hoje.</p>
          ) : (
            <div className="space-y-4">
              {assistantLogs.map((log) => {
                const student = students.find(s => s.id === log.studentId);
                return (
                  <div key={log.id} className="p-4 bg-gray-50 rounded-lg border-l-4 border-blue-500 group hover:bg-blue-50 transition-colors shadow-sm">
                    <p className="font-bold text-sm text-gray-800">{student?.name}</p>
                    <div className="flex justify-between items-center mt-2">
                      <span className="text-[10px] text-gray-500 font-bold uppercase tracking-tight">{log.date}</span>
                      <span className={`text-[10px] px-2 py-1 rounded-full font-bold uppercase h-fit shadow-xs ${
                        log.behavior === 'excelente' ? 'bg-green-100 text-green-700 border border-green-200' :
                        log.behavior === 'bom' ? 'bg-blue-100 text-blue-700 border border-blue-200' :
                        log.behavior === 'regular' ? 'bg-yellow-100 text-yellow-700 border border-yellow-200' : 'bg-red-100 text-red-700 border border-red-200'
                      }`}>
                        {log.behavior}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        <div className="bg-gradient-to-br from-indigo-500 to-purple-600 rounded-xl shadow-lg p-6 text-white overflow-hidden relative">
          <div className="relative z-10">
            <h3 className="text-lg font-bold mb-2">Monitoramento AEE</h3>
            <p className="text-sm opacity-90 leading-relaxed italic">
              "Cada registro ajuda a construir um plano de ensino mais assertivo para o aluno."
            </p>
          </div>
          <svg className="absolute bottom-0 right-0 h-24 w-24 text-white opacity-10 -mr-6 -mb-6" fill="currentColor" viewBox="0 0 24 24">
             <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"/>
          </svg>
        </div>
      </div>
    </div>
  );
};

export default AssistantView;
